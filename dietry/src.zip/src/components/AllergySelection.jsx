import { useState, useEffect } from "react";
import PropTypes from "prop-types";
import "./AllergySelection.css"; // Import the CSS file

const allergiesList = ["Peanuts", "Dairy", "Gluten", "Soy", "Seafood", "Eggs"];

export default function AllergySelection({ userId }) {
  const [selectedAllergies, setSelectedAllergies] = useState([]);

  useEffect(() => {
    if (!userId) return;

    fetch(`/api/user/allergies/${userId}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.allergies) {
          setSelectedAllergies(data.allergies);
        }
      })
      .catch((err) => console.error("Error fetching allergies:", err));
  }, [userId]);

  const handleChange = (event) => {
    const { value, checked } = event.target;
    setSelectedAllergies((prev) =>
      checked ? [...prev, value] : prev.filter((allergy) => allergy !== value)
    );
  };

  const handleSubmit = async () => {
    if (!userId) {
      alert("User ID is missing!");
      return;
    }

    try {
      const response = await fetch("/api/user/allergies", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId, allergies: selectedAllergies }),
      });

      const result = await response.json();
      if (result.success) {
        alert("Allergies saved successfully!");
      } else {
        alert("Failed to save allergies.");
      }
    } catch (error) {
      console.error("Error saving allergies", error);
    }
  };

  return (
    <div className="allergy-container">
      <h2>Select Allergies</h2>
      <div className="allergy-list">
        {allergiesList.map((allergy) => (
          <label key={allergy} className="allergy-item">
            <input
              type="checkbox"
              value={allergy}
              onChange={handleChange}
              checked={selectedAllergies.includes(allergy)}
            />
            {allergy}
          </label>
        ))}
      </div>
      <button className="save-button" onClick={handleSubmit}>
        Save Preferences
      </button>
    </div>
  );
}

// ✅ Add PropTypes validation
AllergySelection.propTypes = {
  userId: PropTypes.string.isRequired,
};
