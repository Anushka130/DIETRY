const mongoose = require("mongoose");

const allergySchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },
    allergies: { type: [String], required: true }
});

const allergyModel = mongoose.model("Allergy", allergySchema);

module.exports = allergyModel;
