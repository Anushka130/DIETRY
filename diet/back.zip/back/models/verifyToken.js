const jwt = require("jsonwebtoken");
const userModel = require("./userModel"); // Import userModel properly

async function verifyToken(req, res, next) {
    const token = req.headers.authorization?.split(" ")[1]; // Extract Bearer token

    if (!token) {
        return res.status(403).send({ message: "Access Denied. No token provided." });
    }

    try {
        const decoded = jwt.verify(token, "diet"); // Verify JWT
        const user = await userModel.findOne({ email: decoded.email });

        if (!user) {
            return res.status(404).send({ message: "User not found" });
        }

        req.user = { id: user._id.toString(), email: user.email }; // Attach userId to request
        next();
    } catch (err) {
        res.status(401).send({ message: "Invalid token" });
    }
}

module.exports = verifyToken;
