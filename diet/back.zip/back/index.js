const express = require("express");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cors = require("cors");
require("dotenv").config();

const userModel = require("./models/userModel");
const foodModel = require("./models/foodModel");
const allergyModel = require("./models/allergyModel"); // NEW
const verifyToken = require("./models/verifyToken");

const PORT = process.env.PORT || 5000;

mongoose
  .connect("mongodb://127.0.0.1:27017/diet", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Database connected successfully"))
  .catch((err) => console.log(err));

const app = express();
app.use(express.json());
app.use(cors());

/**
 * @route POST /register
 * @desc Register a new user
 */
app.post("/register", async (req, res) => {
  try {
    let user = req.body;
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(user.password, salt);
    await userModel.create(user);
    res.status(201).send({ message: "User Registered" });
  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error during registration" });
  }
});

/**
 * @route POST /login
 * @desc User login
 */
app.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await userModel.findOne({ email });

    if (!user) return res.status(404).send({ message: "User not registered" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(403).send({ message: "Incorrect Password" });

    const token = jwt.sign({ email: user.email }, "diet", { expiresIn: "1h" });

    res.send({
      message: "Login Success",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        age: user.age,
        height: user.height,
        weight: user.weight,
        gender: user.gender,
        activityLevel: user.activityLevel,
        goal: user.goal,
        hasDetails: user.hasDetails,
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Server error" });
  }
});

/**
 * @route GET /foods
 * @desc Get all food items (protected)
 */
app.get("/foods", verifyToken, async (req, res) => {
  try {
    const foods = await foodModel.find();
    res.send(foods);
  } catch (err) {
    console.log(err);
    res.status(500).send({ message: "Could not fetch food items" });
  }
});

/**
 * @route POST /user-details
 * @desc Update user details
 */
app.post("/user-details", verifyToken, async (req, res) => {
  try {
    const { height, weight, gender, activityLevel, goal } = req.body;
    const userId = req.user.id;

    const updatedUser = await userModel.findByIdAndUpdate(
      userId,
      { height, weight, gender, activityLevel, goal },
      { new: true }
    );

    if (!updatedUser) return res.status(404).send({ message: "User not found" });

    res.send({ message: "User details updated", user: updatedUser });
  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error updating user details" });
  }
});

/**
 * @route POST /user/allergies
 * @desc Save user allergies
 */
app.post("/user/allergies", verifyToken, async (req, res) => {
  try {
    const { allergies } = req.body;
    const userId = req.user.id;

    if (!Array.isArray(allergies)) {
      return res.status(400).send({ message: "Invalid allergies format" });
    }

    let allergyRecord = await allergyModel.findOne({ userId });

    if (allergyRecord) {
      allergyRecord.allergies = allergies;
      await allergyRecord.save();
    } else {
      allergyRecord = await allergyModel.create({ userId, allergies });
    }

    res.status(200).send({ message: "Allergies saved successfully" });

  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error saving allergies" });
  }
});

/**
 * @route GET /user/allergies/:userId
 * @desc Get user allergies
 */
app.get("/user/allergies/:userId", verifyToken, async (req, res) => {
  try {
    const { userId } = req.params;
    const allergyRecord = await allergyModel.findOne({ userId });

    if (!allergyRecord) {
      return res.status(404).send({ message: "No allergies found" });
    }

    res.status(200).send({ allergies: allergyRecord.allergies });

  } catch (err) {
    console.error(err);
    res.status(500).send({ message: "Error fetching allergies" });
  }
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
